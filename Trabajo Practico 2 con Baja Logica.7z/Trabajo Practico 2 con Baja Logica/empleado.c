#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "empleado.h"
#include "utn.h"

void addEmployee(eEmployee vec[],int tam)
{

    char salaryStr[15];
    char sectorStr[15];
    int indiceLibre;
    int static id=1;
    indiceLibre = searchForFreeSpace(vec,tam);


    if(indiceLibre==-1)
    {
        printf("NO HAY MAS LUGAR EN EL SISTEMA !");
    }
    else
    {
        if(!getStringLetras("Ingrese el nombre :", vec[indiceLibre].name))
        {
            printf("\nIngrese solo letras!!\n\n");
            system("pause");
            return 0;
        }

        if(!getStringLetras("Ingrese el apellido :", vec[indiceLibre].lastName))
        {
            printf("\nIngrese solo letras!!\n\n");
            system("pause");
            return 0;
        }

        if(!getStringFloat("\nIngrese salario :",salaryStr))
        {
            printf("\nIngrese solo numeros!!\n\n");
            system("pause");
            return 0;
        }

        if(!getStringNumeros("Ingrese sector :", sectorStr))
        {
            printf("Error, ingrese solo numeros");
            system("pause");
            return 0;
        }

        vec[indiceLibre].salary=atof(salaryStr); //Convierto el string a numero flotante
        vec[indiceLibre].sector=atoi(sectorStr);
        vec[indiceLibre].isEmpty=1;
        vec[indiceLibre].id=id;
        id++;

    }


}

void showEmployee(eEmployee vec[],int tam)
{
    for(int i=0; i<tam; i++)
    {
        if(vec[i].isEmpty == 1)
        {
            printf("%3d %15s %15s %10.2f %5d\n",vec[i].id,vec[i].lastName,vec[i].name,vec[i].salary,vec[i].sector);
        }
    }

}

void initializeEmployee(eEmployee vec[], int tam)
{
    for(int i=0; i<tam; i++)
    {
        vec[i].isEmpty=0;
    }
}

void removeEmployee(eEmployee vec[],eEmployee vecBaja[],int tam)
{
    int idAux;
    int userFound;
    int auxUserFoundEmployeeDown;
    char confirma;

    showEmployee(vec,tam);
    getInt(&idAux,"Ingrese Id a dar de baja :","Error, ingrese solo numeros",0,100);
    userFound = findEmployeeById(vec,tam,idAux);
    if(userFound == -1)
    {
        printf("\n El usuario no fue encontrado!! \n");
    }
    else
    {
        printf("\nEl usuario pertenece a: %s %s, desea darlo de baja (s/n)?: ",vec[userFound].name,vec[userFound].lastName);
        fflush(stdin);
        scanf("%c", &confirma);
        if(confirma == 's' || confirma == 'S')
        {
            vec[userFound].isEmpty=0;
            auxUserFoundEmployeeDown=searchForFreeSpace(vecBaja,tam);
            vecBaja[auxUserFoundEmployeeDown].isEmpty=1;
            vecBaja[auxUserFoundEmployeeDown].id = vec[userFound].id;
            strcpy(vecBaja[auxUserFoundEmployeeDown].lastName,vec[userFound].lastName);
            strcpy(vecBaja[auxUserFoundEmployeeDown].name,vec[userFound].name);


            printf("\nBAJA EXITOSA!!! \n");
        }
    }
}

int searchForFreeSpace(eEmployee vec[],int tam)
{
    for(int i=0; i< tam; i++)
    {
        if(vec[i].isEmpty==0)
        {
            return i;
        }
    }
    return -1;
}

int findEmployeeById(eEmployee vec[], int tam,int id)
{
    int retorno = -1;
    for(int i=0; i<tam; i++)
    {
        if(vec[i].id == id && vec[i].isEmpty==1)
        {
            retorno = i;
        }
    }
    return retorno;
}

void modificationMenu (eEmployee vec[],int tam)
{
    char seguir = 's';
    char salaryAux[15];
    char sectorAux[15];
    int opcion;
    int idAux;
    int userFound; // Usuario encontrado
    system("cls");
    printf("\n** Menu de modificacion  **\n\n");
    printf(" Id          Apellido        Nombre     Sueldo   Sector\n\n");
    showEmployee(vec,tam);
    printf("\n\nIngrese Id de usuario a modificar :");
    scanf("%d", &idAux);
    userFound = findEmployeeById(vec,tam,idAux);
    if(userFound == -1)
    {
        printf("\nEl usuario no se ha encontrado");
    }
    else
    {
        system("cls");
        printf("*** Menu modificacion  ***");
        printf("\n\nUsuario a modificar: %s %s \n", vec[userFound].lastName,vec[userFound].name);
        printf("\n1-Modificar nombre\n2-Modificar apellido\n3-Modificar salario\n4-Modificar sector\n5-Salir\n\nIngrese opcion :");
        scanf("%d", &opcion);
        while(seguir == 's')
        {
            switch(opcion)
            {
            case 1:
                if(!getStringLetras("Ingrese nuevo nombre :",vec[userFound].name))
                {
                    printf("\nIngrese solo letras !!!");
                    return 0;
                    break;
                }
                printf("\nModificacion exitosa!!");
                break;
            case 2:
                if(!getStringLetras("Ingrese nuevo apellido :",vec[userFound].lastName))
                {
                    printf("\nIngrese solo letras !!!");
                    return 0;
                    break;
                }
                printf("\nModificacion exitosa!!");
                break;
            case 3:
                fflush(stdin);
                if(!getStringFloat("Ingrese nuevo salario :",salaryAux))
                {
                    printf("\nIngrese solo numeros !!!");
                    return 0;
                    break;
                }
                vec[userFound].salary=atof(salaryAux);
                printf("\nModificacion exitosa!!");
                break;
            case 4:
                if(!getStringNumeros("Ingrese nuevo sector :",sectorAux))
                {
                    printf("\nIngrese solo numeros !!!");
                    return 0;
                    break;
                }
                vec[userFound].sector=atoi(sectorAux);
                printf("\nModificacion exitosa!!");
                break;
            case 5:
                seguir = 'n';
                break;
            default:
                printf("Ingrese una opcion correcta (1-5)");
                break;
            }
            return 0;
        }

    }

}

int someActiveEmployee(eEmployee vec[],int tam)
{
    for(int i=0; i<tam; i++)
    {
        if(vec[i].isEmpty==1)
        {
            return 1;
        }
    }
    return 0;
}

void sortEmployeesUpSector(eEmployee vec[],int tam)
{
    eEmployee auxEmpleado;
    for(int i=0; i<tam-1; i++)
    {
        for(int j=i+1; j<tam; j++)
        {
            if(vec[i].sector>vec[j].sector && vec[i].isEmpty==1 && vec[j].isEmpty==1)
            {
                auxEmpleado=vec[i];
                vec[i]=vec[j];
                vec[j]=auxEmpleado;
            }
        }
    }
    printf("\nId          Apellido        Nombre     Sueldo   Sector\n\n");
    showEmployee(vec,100);
}
void sortEmployeesDownSector(eEmployee vec[],int tam)
{


    eEmployee auxEmpleado;
    for(int i=0; i<tam-1; i++)
    {
        for(int j=i+1; j<tam; j++)
        {
            if(vec[i].sector<vec[j].sector && vec[i].isEmpty==1 && vec[j].isEmpty==1)
            {
                auxEmpleado=vec[i];
                vec[i]=vec[j];
                vec[j]=auxEmpleado;
            }
        }
    }
    printf("\nId          Apellido        Nombre     Sueldo   Sector\n\n");
    showEmployee(vec,100);
}


void sortEmployeesDownName(eEmployee vec[],int tam)
{

    eEmployee auxEmpleado;
    for(int i=0; i<tam-1; i++)
    {
        for(int j=i+1; j<tam; j++)
        {
            if((strcmp(vec[i].lastName,vec[j].lastName) < 0) && vec[i].isEmpty==1 && vec[j].isEmpty==1)
            {
                auxEmpleado=vec[i];
                vec[i]=vec[j];
                vec[j]=auxEmpleado;
            }
        }
    }
    printf("\nId          Apellido        Nombre     Sueldo   Sector\n\n");
    showEmployee(vec,100);

}

void sortEmployeesUpName(eEmployee vec[],int tam)
{

    eEmployee auxEmpleado;
    for(int i=0; i<tam-1; i++)
    {
        for(int j=i+1; j<tam; j++)
        {
            if((strcmp(vec[i].lastName,vec[j].lastName) >0) && vec[i].isEmpty==1 && vec[j].isEmpty==1)
            {
                auxEmpleado=vec[i];
                vec[i]=vec[j];
                vec[j]=auxEmpleado;
            }
        }
    }
    printf("\nId          Apellido        Nombre     Sueldo   Sector\n\n");
    showEmployee(vec,100);
}

void averageSalary(eEmployee vec[],int tam)
{
    int contador =0;
    int contadorMayorPromedio=0;
    float recentSalary=0;
    float totalSalary=0;
    float averageSalary=0;

    for(int i=0; i<tam; i++)
    {
        if(vec[i].isEmpty==1)
        {
            recentSalary=vec[i].salary;
            contador++;
            totalSalary=totalSalary+recentSalary;
            averageSalary=totalSalary/contador;
        }

    }

    printf("El total de los salarios es :%.2f\n",totalSalary);
    printf("El promedio del salario total es :%.2f\n",averageSalary);

    for(int i=0; i<tam; i++)
    {
        if(vec[i].isEmpty==1 && vec[i].salary > averageSalary)
        {
            contadorMayorPromedio++;

        }
    }
    printf("La cantidad de personas que superen el promedio es :%d",contadorMayorPromedio);


}

void menuInformes(eEmployee vec[],eEmployee usuariosDadosDeBaja [],int tam){
    int opcion;
    system("cls");
                printf("\n/////////////////INFORMES/////////////////\n\n\n1-Listado de los empleados ordenados alfab�ticamente por Apellido y Sector\n2-Total y promedio de salarios, y cant. empleados superan el salario promedio. \n\nElija opcion :");
            scanf("%d", &opcion);
            switch(opcion)
            {
            case 1:
                system("cls");


                printf("**INFORMES **\n\n");

                mostrarAlumnosDadosDeBaja(usuariosDadosDeBaja,tam);
                printf("\nSector ascendente:");
                sortEmployeesUpSector(vec,tam);

                printf("\nSector Descendente:");
                sortEmployeesDownSector(vec,tam);

                printf("\nApellido Ascendente:");
                sortEmployeesUpName(vec,tam);

                printf("\nApellido Descendente:");
                sortEmployeesDownName(vec,tam);

                printf("\n");
                system("pause");


                break;
            case 2:
                    system("cls");
                    averageSalary(vec,tam);
                    printf("\n\n");
                    showEmployee(vec,tam);
                    system("pause");
                break;
            default:
                break;
            }
}

void mostrarAlumnosDadosDeBaja(eEmployee vecBaja[],int TAM){
    printf("Los usuarios dados de baja son: \n");
    for(int i=0;i<TAM;i++){
        if(vecBaja[i].isEmpty==1){
            printf("%d %s %s\n",vecBaja[i].id,vecBaja[i].lastName,vecBaja[i].name);
        }
    }
}

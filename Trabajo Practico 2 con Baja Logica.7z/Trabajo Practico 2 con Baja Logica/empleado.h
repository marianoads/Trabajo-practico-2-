#ifndef EMPLEADO_H_INCLUDED
#define EMPLEADO_H_INCLUDED
typedef struct
{
    int id;
    char name[51];
    char lastName[51];
    float salary;
    int sector;
    int isEmpty;
} eEmployee;


/** \brief Recibe como parametro el vector de la estructura de empleados y el tama�o
 *
 * \param Busca si hay algun lugar libre en el array. Si hay lugar, pide el ingreso de los datos, y sino muestra por pantalla que no hay lugar.
 * \param
 * \return
 *
 */
void addEmployee(eEmployee vec[],int tam);

/** \brief Recibe como parametro el vector de la estructura de empleados y el tama�o
 *
 * \param Verifica en el vector todos los usuarios que esten activos(isEmpty==1) y los muestra por pantalla
 * \param
 * \return
 *
 */
void showEmployee(eEmployee vec[],int tam);

/** \brief Recibe como parametro el vector de la estructura de empleados y el tama�o
 *
 * \param Inicializa todo el vector de empleados en isEmpty=0(Usuarios no activos)
 * \param
 * \return
 *
 */
void initializeEmployee(eEmployee vec[], int tam);

/** \brief Recibe como parametro el vector de la estructura de empleados y el tama�o
 *
 * \param Muestra los usuarios activos.
 * \param Pide que ingrese el Id del usuario a modificar. Si existe, muestra un menu de opciones del dato que desee modificar, y si no existe notifica por pantalla
 * \return
 *
 */
void modificationMenu (eEmployee vec[],int tam);

/** \brief Recibe como parametro el vector de la estructura de empleados y el tama�o
 *
 * \param Muestra los usuarios activos.
 * \param Pide que ingrese el Id del usuario a dar de baja. Si existe, se da la baja logica, y si no existe notifica por pantalla
 * \return
 *
 */
void removeEmployee(eEmployee vec[],eEmployee vecBaja[],int tam);

/** \brief Recibe como parametro el vector de la estructura de empleados y el tama�o
 *
 * \param Busca en el vector de la estructura empleados si existe algun espacio libre para ser utilizado.
 * \param
 * \return Si existe espacio libre, devuelve el indice, y sino devuelve -1.
 *
 */
int searchForFreeSpace(eEmployee vec[],int tam);

/** \brief Recibe como parametro el vector de la estructura de empleados, el tama�o y el id a buscar
 *
 * \param Busca en el vector, si el id ingresado coincide con alguno de los activos.
 * \param Si lo encuentra, devuelve el indice, y si no lo encuentra retorna error
 * \return Usuario encontrado retorna su indice. Usuario no encontrado retorna -1
 *
 */
int findEmployeeById(eEmployee vec[], int tam,int id);

/** \brief Recibe como parametro el vector de la estructura de empleados y el tama�o
 *
 * \param Verifica si existe algunn empleado activo
 * \param
 * \return Retorna 1 si existe algun empleado activo. Retorna -1 si no existe ningun empleado registrado
 *
 */
int someActiveEmployee(eEmployee vec[],int tam);

/** \brief Recibe como parametro el vector de la estructura de empleados y el tama�o
 *
 * \param Calcula la suma total de los salarios, el promedio general de salarios y los muestra
 * \param Tambien muestra por pantalla cantidad de empleados que superan el promedio general de salarios
 * \return
 *
 */
void averageSalary(eEmployee vec[],int tam);

/** \brief Recibe como parametro el vector de la estructura de empleados y el tama�o
 *
 * \param Ordena el vector de empleados p�r apellido de forma ascendente
 * \param
 * \return
 *
 */
void sortEmployeesUpName(eEmployee vec[],int tam);

/** \brief  Recibe como parametro el vector de la estructura de empleados y el tama�o
 *
 * \param Ordena el vector de empleados p�r apellido de forma descendente
 * \param
 * \return
 *
 */
void sortEmployeesDownName(eEmployee vec[],int tam);

/** \brief Recibe como parametro el vector de la estructura de empleados y el tama�o
 *
 * \param Ordena el vector de empleados p�r sector de forma ascendente
 * \param
 * \return
 *
 */
void sortEmployeesDownSector(eEmployee vec[],int tam);

/** \brief Recibe como parametro el vector de la estructura de empleados y el tama�o
 *
 * \param Ordena el vector de empleados p�r sector de forma ascendente
 * \param
 * \param
 * \return
 *
 */
void sortEmployeesUpSector(eEmployee vec[],int tam);

void menuInformes(eEmployee vec[],eEmployee usuariosDadosDeBaja [],int tam);

void mostrarAlumnosDadosDeBaja(eEmployee vecBaja[],int TAM);

#endif // EMPLEADO_H_INCLUDED

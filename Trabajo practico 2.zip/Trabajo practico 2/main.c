#include <stdio.h>
#include <stdlib.h>
#include "empleado.h"
#include "utn.h"

int main()
{
    eEmployee empleado[100];

    eEmployee harcodeEmpleado[100] = {{1,"Mariano","Yamakawa",90000,9,1},{2,"Jose","Perez",85500,1,1},{3,"Carlos","Diaz",14500,4,1},{4,"Belen","Manzaba",50000,6,1},{5,"Juliana","Valls",150000,6,1}};

    int opcion;
    char seguir = 's';
    printf("/////////////// ABM //////////////");

    initializeEmployee(empleado, 100);

    while(seguir=='s')
    {


        printf("\n\n1-ALTA\n2-MODIFICAR\n3-BAJA\n4-INFORMAR\n5-SALIR\n\nIngrese opcion :");
        scanf("%d", &opcion);

        switch(opcion)
        {
        case 1:
            addEmployee(harcodeEmpleado,100);
            break;
        case 2:
            if(!someActiveEmployee(harcodeEmpleado,100))
            {
                printf("\nNo se encuentra registrado ningun empleado !!\n");
            }
            else
            {
                modificationMenu(harcodeEmpleado,100);
            }

            break;
        case 3:
            if(!someActiveEmployee(harcodeEmpleado,100))
            {
                printf("\nNo se encuentra registrado ningun empleado !!\n");
            }
            else
            {
                removeEmployee(harcodeEmpleado,100);
            }

            break;
        case 4:
            if(!someActiveEmployee(harcodeEmpleado,100))
            {
                printf("\nNo se encuentra registrado ningun empleado !!\n");
            }
            else{
                system("cls");
                printf("\n/////////////////INFORMES/////////////////\n\n\n1-Listado de los empleados ordenados alfab�ticamente por Apellido y Sector\n2-Total y promedio de salarios, y cant. empleados superan el salario promedio. \n\nElija opcion :");
            scanf("%d", &opcion);
            switch(opcion)
            {
            case 1:
                system("cls");



                printf("**INFORMES **\n\n");
                printf("\nSector ascendente:");
                sortEmployeesUpSector(harcodeEmpleado,100);

                printf("\nSector Descendente:");
                sortEmployeesDownSector(harcodeEmpleado,100);

                printf("\nApellido Ascendente:");
                sortEmployeesUpName(harcodeEmpleado,100);

                printf("\nApellido Descendente:");
                sortEmployeesDownName(harcodeEmpleado,100);

                printf("\n");


                break;
            case 2:
                    averageSalary(harcodeEmpleado,100);
                    printf("\n\n");
                    showEmployee(harcodeEmpleado,100);
                break;
            default:
                break;
            }
            }

            break;
        case 5:
            seguir = 'n';
            break;
        default:
            printf("Ingrese una opcion correcta (1-5)");
            break;
        }
    }

    return 0;
}


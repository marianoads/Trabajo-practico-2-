#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "empleado.h"
#include "utn.h"
#define TAM 100
int main()
{
    eEmployee empleado[TAM];

    eEmployee harcodeEmpleado[TAM] = {{1,"Mariano","Yamakawa",90000,9,1},{2,"Jose","Perez",85500,1,1},{3,"Carlos","Diaz",14500,4,1},{4,"Belen","Manzaba",50000,6,1},{5,"Juliana","Valls",150000,6,1}};

    int opcion;
    char seguir = 's';
    printf("/////////////// ABM //////////////");

    initializeEmployee(empleado, TAM);

    while(seguir=='s')
    {

        system("cls");
        printf("\n\n1-ALTA\n2-MODIFICAR\n3-BAJA\n4-INFORMAR\n5-SALIR\n\nIngrese opcion :");
        scanf("%d", &opcion);

        switch(opcion)
        {
        case 1:
            addEmployee(harcodeEmpleado,TAM);
            break;
        case 2:
            if(!someActiveEmployee(harcodeEmpleado,TAM))    // VERIFICO SI HAY ALGUN EMPLEADO ACTIVO
            {
                printf("\nNo se encuentra registrado ningun empleado !!\n");
                system("pause");
            }
            else
            {
                modificationMenu(harcodeEmpleado,TAM);
            }

            break;
        case 3:
            if(!someActiveEmployee(harcodeEmpleado,TAM))    // VERIFICO SI HAY ALGUN EMPLEADO ACTIVO
            {
                printf("\nNo se encuentra registrado ningun empleado !!\n");
                system("pause");
            }
            else
            {
                removeEmployee(harcodeEmpleado,TAM);
            }

            break;
        case 4:
            if(!someActiveEmployee(harcodeEmpleado,TAM))    // VERIFICO SI HAY ALGUN EMPLEADO ACTIVO
            {
                printf("\nNo se encuentra registrado ningun empleado !!\n");
                system("pause");
            }
            else{
                menuInformes(harcodeEmpleado, TAM);
            }

            break;
        case 5:
            seguir = 'n';
            break;
        default:
            printf("Ingrese una opcion correcta (1-5)");
            break;
        }
    }

    return 0;
}

